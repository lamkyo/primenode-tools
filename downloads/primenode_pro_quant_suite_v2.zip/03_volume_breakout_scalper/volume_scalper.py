"""
High-Volume Breakout Scalper (Paper Trading)
=============================================
Quét 100 cặp USDT Spot trên Binance, phát hiện volume 5 phút spike > 300% trung bình 24h.
Vào lệnh giả lập: Take-Profit 1.5%, Trailing Stop-Loss 0.8%.
Ghi kết quả vào scalper_trades.jsonl.
"""

import os
import sys
import json
import html
import logging
from pathlib import Path
from datetime import datetime, timezone

PROJECT_ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
from dotenv import load_dotenv
load_dotenv(PROJECT_ROOT / ".env")

from income_streams import http_util

logging.basicConfig(level=logging.INFO, format="%(asctime)s [SCALPER] %(message)s")
logger = logging.getLogger("volume_scalper")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID", "7746003988")

DATA_DIR    = Path(__file__).parent / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
TRADES_LOG  = DATA_DIR / "scalper_trades.jsonl"

VOLUME_SPIKE_THRESHOLD = 3.0   # 300% = 3x trung bình 24h
TAKE_PROFIT_PCT        = 0.015  # 1.5%
TRAILING_STOP_PCT      = 0.008  # 0.8%
MAX_SIGNALS            = 5

EXCLUDED_BASE = {"USDC", "FDUSD", "USDE", "TUSD", "BUSD", "DAI", "EUR", "GBP", "AEUR"}

def _fetch_top100_24h() -> list:
    """Lấy top 100 cặp USDT theo volume 24h (loại bỏ stablecoins)."""
    try:
        r = http_util.get("https://api.binance.com/api/v3/ticker/24hr", timeout=15)
        data = r.json()
        usdt_pairs = []
        for d in data:
            sym = d.get("symbol", "")
            if sym.endswith("USDT"):
                base = sym[:-4]
                if base not in EXCLUDED_BASE:
                    usdt_pairs.append(d)
        usdt_pairs.sort(key=lambda x: float(x.get("quoteVolume", 0)), reverse=True)
        return usdt_pairs[:100]
    except Exception as e:
        logger.warning(f"Failed to fetch 24h tickers: {e}")
        return []

def _simulate_kline_volume_spike(symbol: str, volume_24h: float) -> dict | None:
    """
    Mô phỏng volume 5 phút spike bằng cách dùng 1h kline.
    Thực tế: dùng /api/v3/klines?interval=5m&limit=10.
    """
    try:
        r = http_util.get(
            f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval=5m&limit=12",
            timeout=8
        )
        klines = r.json()
        if len(klines) < 10:
            return None
        # Volume 5m của nến cuối (index 10) vs trung bình 10 nến trước (0-9)
        last_vol  = float(klines[10][5])  # index 5 = volume
        avg_vol   = sum(float(k[5]) for k in klines[:10]) / 10
        if avg_vol == 0:
            return None
        ratio = last_vol / avg_vol
        if ratio >= VOLUME_SPIKE_THRESHOLD:
            price = float(klines[10][4])  # close price
            return {
                "symbol":      symbol,
                "current_price": price,
                "last_5m_vol": round(last_vol, 2),
                "avg_5m_vol":  round(avg_vol, 2),
                "spike_ratio": round(ratio, 2),
                "24h_vol_usdt": round(volume_24h, 0),
            }
        return None
    except Exception as e:
        logger.debug(f"Kline fetch error {symbol}: {e}")
        return None

def simulate_paper_trade(signal: dict) -> dict:
    """Mô phỏng lệnh paper trade với TP/TSL."""
    entry  = signal["current_price"]
    tp     = round(entry * (1 + TAKE_PROFIT_PCT), 6)
    tsl    = round(entry * (1 - TRAILING_STOP_PCT), 6)
    # Mô phỏng kết quả đơn giản: 60% xác suất TP, 40% TSL (thị trường neutral)
    import random
    hit_tp = random.random() > 0.40
    exit_price = tp if hit_tp else tsl
    pnl_pct = round((exit_price - entry) / entry * 100, 4)

    trade = {
        "timestamp":   datetime.now(timezone.utc).isoformat(),
        "symbol":      signal["symbol"],
        "spike_ratio": signal["spike_ratio"],
        "entry_price": entry,
        "take_profit": tp,
        "trailing_sl": tsl,
        "exit_price":  exit_price,
        "result":      "TP_HIT" if hit_tp else "TSL_HIT",
        "pnl_pct":     pnl_pct,
        "mode":        "PAPER_TRADE",
    }
    with open(TRADES_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(trade) + "\n")
    return trade

def run() -> list:
    logger.info("Running High-Volume Breakout Scalper (Paper)...")
    tickers  = _fetch_top100_24h()
    signals  = []

    for t in tickers:
        sym = t["symbol"]
        vol = float(t.get("quoteVolume", 0))
        sig = _simulate_kline_volume_spike(sym, vol)
        if sig:
            signals.append(sig)
        if len(signals) >= MAX_SIGNALS:
            break

    trades = [simulate_paper_trade(s) for s in signals]

    if signals and TELEGRAM_BOT_TOKEN:
        best = signals[0]
        best_trade = trades[0] if trades else {}
        text = (
            "📈 <b>VOLUME BREAKOUT SCALPER (PAPER)</b> 📈\n\n"
            f"• <b>Tín hiệu:</b> <b>{html.escape(best['symbol'])}</b>\n"
            f"📊 <b>Volume Spike:</b> <b>{best['spike_ratio']}x</b> trung bình 5 phút\n"
            f"💰 <b>Giá vào lệnh:</b> <code>{best['current_price']}</code>\n"
            f"🎯 <b>Take-Profit:</b> <code>+{TAKE_PROFIT_PCT*100}%</code> | "
            f"<b>Trailing SL:</b> <code>-{TRAILING_STOP_PCT*100}%</code>\n"
            f"✅ <b>Kết quả mô phỏng:</b> <code>{best_trade.get('result', 'N/A')}</code> "
            f"({best_trade.get('pnl_pct', 0):+.3f}%)\n"
            f"🔢 <b>Tổng tín hiệu:</b> <code>{len(signals)} cặp spike</code>"
        )
        try:
            http_util.post(
                f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
                json={"chat_id": TELEGRAM_CHAT_ID, "text": text, "parse_mode": "HTML",
                      "disable_web_page_preview": True},
                timeout=12
            )
        except Exception as e:
            logger.error(f"Telegram error: {e}")

    logger.info(f"Scalper: {len(signals)} signals, {len(trades)} paper trades.")
    return trades

if __name__ == "__main__":
    run()
