# PrimeNode Commercial AFL Indicators & Screeners for AmiBroker

## 📦 Package Contents
1. `volume_breakout_pro.afl`: High-Volume Breakout indicator with ATR dynamic trail stops and analysis exploration.
2. `supertrend_mtf_pro.afl`: Multi-timeframe trend-following indicator with bullish/bearish flip signals.
3. `smc_liquidity_sweep.afl`: Smart Money Concepts institutional liquidity grab detector.
4. `vn30_stock_master_screener.afl`: Stage-2 Minervini momentum stock screener with 20MA volume surges and MACD triggers.

## 🛠 How to Install in AmiBroker
1. Copy the `.afl` files into: `C:\Program Files\AmiBroker\Formulas\Custom\`
2. Open AmiBroker -> Charts pane -> Custom folder -> Double-click or drag onto your chart.
3. For Screeners: Open Analysis window -> Pick Formula -> Click **Explore**.
