"""
Binance Grid Trading Bot — 100% Automated
==========================================
Tự động tạo + quản lý grid orders trên Binance.
Grid = đặt nhiều lệnh mua/bán theo từng mức giá → kiếm tiền từ dao động.

Strategy: 
- Mua thấp, bán cao trong range định trước
- Mỗi grid = 1 lệnh mua + 1 lệnh bán
- Tự động reset khi giá ra ngoài range

Phù hợp: Thị trường sideways (dao động trong range)
Ví dụ: XRP $1.40-$1.80 → đặt 20 lưới → mỗi lần dao động ăn 0.2%
"""

import os
import sys
import json
import time
import hmac
import hashlib
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Dict, Optional
import httpx
from dotenv import load_dotenv

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
load_dotenv(Path(__file__).parent.parent.parent / ".env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [GRID] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(Path(__file__).parent / "grid_bot.log"),
    ]
)
logger = logging.getLogger("grid_bot")

API_KEY    = os.getenv("BINANCE_API_KEY", "")
API_SECRET = os.getenv("BINANCE_API_SECRET", "")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID", "")
BASE_URL   = "https://api.binance.com"


class BinanceGridBot:
    """
    Grid trading bot for Binance Spot.
    
    Đặt N lưới giữa price_low và price_high.
    Mỗi lưới = 1 buy + 1 sell order.
    """

    def __init__(self, symbol: str, price_low: float, price_high: float,
                 grid_count: int = 10, total_usdt: float = 50.0, dry_run: bool = True):
        self.symbol      = symbol.upper()
        self.price_low   = price_low
        self.price_high  = price_high
        self.grid_count  = grid_count
        self.total_usdt  = total_usdt
        self.dry_run     = dry_run
        self.client      = httpx.Client(trust_env=False, timeout=30)
        self.log_path    = Path(__file__).parent / f"grid_{symbol.lower()}.jsonl"
        self.state_path  = Path(__file__).parent / f"state_{symbol.lower()}.json"

        self.grid_step   = (price_high - price_low) / grid_count
        self.usdt_per_grid = total_usdt / grid_count
        self.active_orders: List[Dict] = []

        logger.info(f"Grid Bot: {symbol}")
        logger.info(f"  Range: ${price_low:.4f} — ${price_high:.4f}")
        logger.info(f"  Grids: {grid_count} × ${self.usdt_per_grid:.2f} USDT each")
        logger.info(f"  Step: {self.grid_step:.4f} ({self.grid_step/price_low*100:.2f}%)")
        logger.info(f"  Mode: {'DRY RUN (paper trading)' if dry_run else '🔴 LIVE TRADING'}")

    def _sign(self, params: str) -> str:
        return hmac.new(API_SECRET.encode(), params.encode(), hashlib.sha256).hexdigest()

    def _request(self, method: str, endpoint: str, params: dict = None, signed: bool = False) -> dict:
        params = params or {}
        if signed:
            params["timestamp"] = int(time.time() * 1000)
            query = "&".join(f"{k}={v}" for k, v in params.items())
            params["signature"] = self._sign(query)

        headers = {"X-MBX-APIKEY": API_KEY}
        url = BASE_URL + endpoint
        for _attempt in range(3):
            try:
                if _attempt > 0:
                    time.sleep(2 * _attempt)
                if method == "GET":
                    r = self.client.get(url, params=params, headers=headers)
                elif method == "POST":
                    r = self.client.post(url, params=params, headers=headers)
                elif method == "DELETE":
                    r = self.client.delete(url, params=params, headers=headers)
                else:
                    raise ValueError(f"Unknown method: {method}")

                r.raise_for_status()
                if r.status_code in (418, 429):
                    logger.warning("rate-limit retry")
                    time.sleep(min(60, (2 ** _attempt) * 2))
                    continue
                return r.json()
            except httpx.HTTPStatusError as e:
                logger.warning(f"HTTP {e.response.status_code} {endpoint} - retry lan {_attempt+1}/3")
                time.sleep(min(60, (2 ** _attempt) * 2))
                continue
                logger.error(f"HTTP {e.response.status_code}: {e.response.text[:200]}")
                return {}
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.ConnectTimeout,
                    httpx.RemoteProtocolError) as e:
                logger.warning(f"Network {type(e).__name__} {endpoint} - retry lan {_attempt+1}/3")
                continue
            except Exception as e:
                logger.error(f"Request error: {e}")
                return {}
        logger.error(f"Request {endpoint} that bai sau 3 lan retry")
        return {}

    def get_current_price(self) -> float:
        data = self._request("GET", "/api/v3/ticker/price", {"symbol": self.symbol})
        return float(data.get("price", 0))

    def get_symbol_info(self) -> dict:
        """Get trading pair precision info."""
        data = self._request("GET", "/api/v3/exchangeInfo")
        for s in data.get("symbols", []):
            if s["symbol"] == self.symbol:
                return s
        return {}

    def get_balance(self, asset: str) -> float:
        """Get asset balance."""
        data = self._request("GET", "/api/v3/account", signed=True)
        for b in data.get("balances", []):
            if b["asset"] == asset:
                return float(b["free"])
        return 0.0

    def get_open_orders(self) -> List[Dict]:
        return self._request("GET", "/api/v3/openOrders", {"symbol": self.symbol}, signed=True)

    def cancel_all_orders(self):
        """Cancel all open orders."""
        orders = self.get_open_orders()
        if not orders:
            logger.info("No open orders to cancel")
            return
        result = self._request("DELETE", "/api/v3/openOrders", {"symbol": self.symbol}, signed=True)
        logger.info(f"Cancelled {len(orders)} orders")
        return result

    def calculate_grid_levels(self) -> List[float]:
        """Calculate all grid price levels."""
        levels = []
        for i in range(self.grid_count + 1):
            price = self.price_low + (i * self.grid_step)
            levels.append(round(price, 6))
        return levels

    def get_quantity_precision(self) -> int:
        info = self.get_symbol_info()
        for f in info.get("filters", []):
            if f["filterType"] == "LOT_SIZE":
                step = f["stepSize"].rstrip('0')
                if '.' in step:
                    return len(step.split('.')[-1])
        return 4

    def setup_grid(self) -> List[Dict]:
        """Place all grid orders."""
        current_price = self.get_current_price()
        levels = self.calculate_grid_levels()
        qty_precision = self.get_quantity_precision()

        if current_price < self.price_low or current_price > self.price_high:
            logger.warning(f"Current price ${current_price:.4f} is OUTSIDE grid range!")
            logger.warning(f"Grid: ${self.price_low:.4f} — ${self.price_high:.4f}")
            return []

        logger.info(f"Current price: ${current_price:.4f}")
        logger.info(f"Placing {self.grid_count} grid levels...")

        placed = []
        for i, level in enumerate(levels[:-1]):
            buy_price  = level
            sell_price = levels[i + 1]
            qty = round(self.usdt_per_grid / buy_price, qty_precision)

            if buy_price < current_price:
                # Place BUY order below current price
                order_type = "BUY"
                price = buy_price
            else:
                # Place SELL order above current price
                order_type = "SELL"
                price = sell_price

            order_info = {
                "grid_level": i,
                "side": order_type,
                "price": round(price, 6),
                "quantity": qty,
                "total_usdt": round(qty * price, 2),
                "status": "pending",
                "ts": datetime.now(timezone.utc).isoformat(),
            }

            if self.dry_run:
                order_info["status"] = "simulated"
                order_info["order_id"] = f"DRY-{i+1:04d}"
                logger.info(f"  [DRY] {order_type:4} {qty:.6f} {self.symbol} @ ${price:.4f} (${qty*price:.2f})")
            else:
                params = {
                    "symbol": self.symbol,
                    "side": order_type,
                    "type": "LIMIT",
                    "timeInForce": "GTC",
                    "quantity": qty,
                    "price": round(price, 6),
                    "newOrderRespType": "RESULT",
                }
                result = self._request("POST", "/api/v3/order", params, signed=True)
                if result.get("orderId"):
                    order_info["order_id"] = result["orderId"]
                    order_info["status"] = "placed"
                    logger.info(f"  ✅ {order_type:4} {qty:.6f} @ ${price:.4f} → ID:{result['orderId']}")
                else:
                    order_info["status"] = "failed"
                    logger.error(f"  ❌ Failed: {result}")

            placed.append(order_info)
            time.sleep(0.1)  # Rate limit

        self.active_orders = placed
        self._save_state(placed, current_price)
        return placed

    def check_fills(self, current_price: float) -> List[Dict]:
        """So giá hiện tại với grid levels trong state → phát hiện lưới đã khớp (paper)."""
        fills: List[Dict] = []
        try:
            if not self.state_path.exists():
                return fills
            state = json.loads(self.state_path.read_text())
            for o in state.get("orders", []):
                key = f"{o['side']}@{o['price']}"
                if key in state.get("fills", []):
                    continue
                if o["side"] == "BUY" and current_price <= o["price"]:
                    fills.append(o)
                    state.setdefault("fills", []).append(key)
                elif o["side"] == "SELL" and current_price >= o["price"]:
                    fills.append(o)
                    state.setdefault("fills", []).append(key)
            if fills:
                self.state_path.write_text(json.dumps(state, indent=2))
                logger.info(f"{len(fills)} grid fills @ ${current_price:.4f}")
                self._record_pnl_fills(fills, current_price)
        except Exception as e:
            logger.error(f"check_fills error: {e}")
        return fills

    # ------------------------------------------------------------------
    # Dynamic Auto-Rebalance (EMA50 + ATR14 trên nến 1h) + PnL history
    # ------------------------------------------------------------------
    PNL_PATH = Path(__file__).parent / "pnl_history.jsonl"

    def fetch_klines_1h(self, limit: int = 60) -> List[Dict]:
        """Nến 1h public (không cần key). Trả về list {close, high, low}."""
        r = self.client.get(BASE_URL + "/api/v3/klines",
                            params={"symbol": self.symbol, "interval": "1h", "limit": limit})
        klines = r.json()
        return [{"high": float(k[2]), "low": float(k[3]), "close": float(k[4])}
                for k in klines]

    @staticmethod
    def compute_ema(values: List[float], period: int = 50) -> float:
        k = 2 / (period + 1)
        ema = values[0]
        for v in values[1:]:
            ema = v * k + ema * (1 - k)
        return ema


    @staticmethod
    def compute_bollinger(values, period: int = 20, mult: float = 2.0):
        """Bollinger Bands cross-check cho auto-rebalance. Tra ve (mid, upper, lower)."""
        import math
        seg = values[-period:]
        mid = sum(seg) / len(seg)
        var = sum((v - mid) ** 2 for v in seg) / len(seg)
        sd = math.sqrt(var)
        return (mid, mid + mult * sd, mid - mult * sd)

    @staticmethod
    def compute_atr(klines: List[Dict], period: int = 14) -> float:
        trs = []
        prev_close = klines[0]["close"]
        for k in klines:
            tr = max(k["high"] - k["low"], abs(k["high"] - prev_close),
                     abs(k["low"] - prev_close))
            trs.append(tr)
            prev_close = k["close"]
        return sum(trs[-period:]) / period

    def auto_rebalance(self) -> Optional[Dict]:
        """Nếu giá vượt dải → re-center quanh EMA50, nửa dải = max(ATR*1.5, 3%).
        Trả về dict range mới hoặc None nếu vẫn trong dải."""
        price = self.get_current_price()
        if price is None:
            return None
        if self.price_low <= price <= self.price_high:
            return None
        try:
            klines = self.fetch_klines_1h()
            closes = [k["close"] for k in klines]
            ema50 = self.compute_ema(closes, 50)
            atr14 = self.compute_atr(klines, 14)
            half = max(atr14 * 1.5, ema50 * 0.03)
            new_low, new_high = round(ema50 - half, 6), round(ema50 + half, 6)
        except Exception as e:
            logger.error(f"auto_rebalance klines fail: {e}")
            return None
        old = (self.price_low, self.price_high)
        self.price_low, self.price_high = new_low, new_high
        self.grid_step = (new_high - new_low) / self.grid_count
        logger.info(f"REBALANCE {self.symbol}: {old} → ({new_low}, {new_high}) "
                    f"EMA50={ema50:.4f} ATR14={atr14:.4f}")
        self.send_telegram(
            f"Grid Rebalance {self.symbol}\nGia {price} vuot dai cu {old}\n"
            f"Dai moi: {new_low} - {new_high} (EMA50 {ema50:.4f}, ATR14 {atr14:.4f})")
        return {"symbol": self.symbol, "old_range": list(old),
                "new_low": new_low, "new_high": new_high,
                "ema50": round(ema50, 6), "atr14": round(atr14, 6), "price": price}

    def _record_pnl_fills(self, fills: List[Dict], current_price: float) -> None:
        """Ghép cặp BUY-thấp/SELL-cao đã khớp → ghi realized PnL vào pnl_history.jsonl."""
        try:
            state = json.loads(self.state_path.read_text()) if self.state_path.exists() else {}
            buys = sorted([o["price"] for o in fills if o["side"] == "BUY"])
            sells = sorted([o["price"] for o in fills if o["side"] == "SELL"])
            pairs = min(len(buys), len(sells))
            if pairs == 0:
                return
            qty = self.usdt_per_grid / ((sum(buys[:pairs]) + sum(sells[:pairs])) / (2 * pairs))
            for b, s in zip(buys[:pairs], sells[:pairs]):
                if s <= b:
                    continue
                profit = (s - b) * qty
                entry = {"ts": datetime.now(timezone.utc).isoformat(), "pair": self.symbol,
                         "buy_price": b, "sell_price": s, "qty": round(qty, 6),
                         "profit_usdt": round(profit, 4),
                         "profit_pct": round((s - b) / b * 100, 3),
                         "mode": "paper" if self.dry_run else "live"}
                with open(self.PNL_PATH, "a") as f:
                    f.write(json.dumps(entry) + "\n")
                logger.info(f"PnL {self.symbol}: buy {b} sell {s} → +${profit:.4f}")
        except Exception as e:
            logger.error(f"_record_pnl_fills error: {e}")

    def _save_state(self, orders: list, price: float):
        state = {
            "symbol": self.symbol,
            "price_low": self.price_low,
            "price_high": self.price_high,
            "grid_count": self.grid_count,
            "total_usdt": self.total_usdt,
            "current_price": price,
            "orders_placed": len(orders),
            "ts": datetime.now(timezone.utc).isoformat(),
            "orders": orders,
        }
        self.state_path.write_text(json.dumps(state, indent=2))

        with open(self.log_path, "a") as f:
            f.write(json.dumps({"event": "grid_setup", **state}) + "\n")

    def send_telegram(self, msg: str):
        if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
            return
        try:
            self.client.post(
                f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
                json={"chat_id": TELEGRAM_CHAT_ID, "text": msg[:4096]},
                timeout=10,
            )
        except Exception as e:
            logger.error(f"Telegram: {e}")

    def monitor(self, interval_seconds: int = 300):
        """Monitor grid bot — check filled orders and replace."""
        logger.info(f"Monitoring {self.symbol} every {interval_seconds}s...")
        filled_count = 0
        total_profit = 0.0

        while True:
            try:
                current_price = self.get_current_price()

                # Check if price is in range
                in_range = self.price_low <= current_price <= self.price_high
                if not in_range:
                    msg = (f"GRID BOT ALERT — {self.symbol}\n"
                           f"Price ${current_price:.4f} out of range!\n"
                           f"Range: ${self.price_low:.4f}–${self.price_high:.4f}\n"
                           f"Consider adjusting grid.")
                    logger.warning(msg)
                    self.send_telegram(msg)

                # Check open orders (count filled)
                if not self.dry_run:
                    open_orders = self.get_open_orders()
                    newly_filled = self.grid_count - len(open_orders)
                    if newly_filled > filled_count:
                        profit_est = (newly_filled - filled_count) * self.usdt_per_grid * (self.grid_step / ((self.price_low + self.price_high) / 2))
                        total_profit += profit_est
                        filled_count = newly_filled
                        msg = (f"GRID BOT — {self.symbol}\n"
                               f"Orders filled: {newly_filled}/{self.grid_count}\n"
                               f"Est profit: ${total_profit:.4f}\n"
                               f"Price: ${current_price:.4f}")
                        logger.info(f"Filled: {newly_filled} | Est profit: ${total_profit:.4f}")
                        self.send_telegram(msg)

                logger.info(f"Price: ${current_price:.4f} | Range: {'IN' if in_range else 'OUT'} | Filled: {filled_count}")
                time.sleep(interval_seconds)

            except KeyboardInterrupt:
                logger.info("Grid bot stopped by user")
                break
            except Exception as e:
                logger.error(f"Monitor error: {e}")
                time.sleep(60)

    def status_report(self) -> dict:
        """Get current status."""
        current_price = self.get_current_price()
        open_orders   = self.get_open_orders() if not self.dry_run else []
        usdt_balance  = self.get_balance("USDT")
        coin = self.symbol.replace("USDT", "")
        coin_balance  = self.get_balance(coin)

        report = {
            "symbol": self.symbol,
            "current_price": current_price,
            "range": f"${self.price_low:.4f} — ${self.price_high:.4f}",
            "in_range": self.price_low <= current_price <= self.price_high,
            "open_orders": len(open_orders),
            "usdt_balance": usdt_balance,
            "coin_balance": coin_balance,
            "grid_step_pct": f"{self.grid_step/((self.price_low+self.price_high)/2)*100:.2f}%",
        }
        return report


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Binance Grid Bot")
    parser.add_argument("--symbol",   default="XRPUSDT", help="Trading pair (default: XRPUSDT)")
    parser.add_argument("--low",      type=float, default=None, help="Grid low price")
    parser.add_argument("--high",     type=float, default=None, help="Grid high price")
    parser.add_argument("--grids",    type=int,   default=10,   help="Number of grid levels (default: 10)")
    parser.add_argument("--usdt",     type=float, default=50.0, help="Total USDT to use (default: 50)")
    parser.add_argument("--live",     action="store_true",      help="Enable LIVE trading (default: dry run)")
    parser.add_argument("--monitor",  action="store_true",      help="Monitor after setup")
    parser.add_argument("--status",   action="store_true",      help="Show status only")
    parser.add_argument("--cancel",   action="store_true",      help="Cancel all open orders")
    args = parser.parse_args()

    # Auto-detect grid range from 24h data if not provided
    if args.low is None or args.high is None:
        with httpx.Client(trust_env=False, timeout=15) as c:
            r = c.get(f"https://api.binance.com/api/v3/ticker/24hr?symbol={args.symbol}")
            d = r.json()
            low_24h  = float(d["lowPrice"])
            high_24h = float(d["highPrice"])
            current  = float(d["lastPrice"])
            # Use 80% of 24h range, centered on current price
            half_range = (high_24h - low_24h) * 0.8 / 2
            args.low  = args.low  or round(current - half_range, 6)
            args.high = args.high or round(current + half_range, 6)
            print(f"Auto-detected range: ${args.low:.4f} — ${args.high:.4f} (from 24h: ${low_24h:.4f}—${high_24h:.4f})")

    bot = BinanceGridBot(
        symbol=args.symbol,
        price_low=args.low,
        price_high=args.high,
        grid_count=args.grids,
        total_usdt=args.usdt,
        dry_run=not args.live,
    )

    if args.status:
        report = bot.status_report()
        print(json.dumps(report, indent=2))
        return

    if args.cancel:
        bot.cancel_all_orders()
        return

    # Setup grid
    orders = bot.setup_grid()
    
    summary = {
        "symbol": args.symbol,
        "mode": "LIVE" if args.live else "DRY RUN",
        "range": f"${args.low:.4f} — ${args.high:.4f}",
        "grids": args.grids,
        "total_usdt": args.usdt,
        "usdt_per_grid": round(args.usdt / args.grids, 2),
        "grid_step_pct": round((args.high - args.low) / args.grids / ((args.low + args.high) / 2) * 100, 3),
        "orders_placed": len(orders),
        "estimated_monthly_return": f"{round((args.high-args.low)/args.grids/((args.low+args.high)/2)*100*2*30, 1)}% (nếu 2 giao dịch/ngày/lưới)",
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))

    # Notify Telegram
    bot.send_telegram(
        f"Grid Bot Setup — {args.symbol}\n"
        f"Mode: {summary['mode']}\n"
        f"Range: {summary['range']}\n"
        f"Grids: {args.grids} x ${summary['usdt_per_grid']} USDT\n"
        f"Step: {summary['grid_step_pct']}%\n"
        f"Est return: {summary['estimated_monthly_return']}"
    )

    if args.monitor:
        bot.monitor(interval_seconds=300)


if __name__ == "__main__":
    main()
