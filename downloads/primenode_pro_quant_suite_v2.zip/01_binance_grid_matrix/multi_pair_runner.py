"""
Binance Multi-Pair Dynamic Grid Matrix Runner
=============================================
Chạy đồng thời 5 bot lưới trên 5 cặp: XRPUSDT, SOLUSDT, BNBUSDT, DOGEUSDT, ADAUSDT.
Mỗi cặp phân bổ $50 vốn ảo (paper trading). Hỗ trợ Dynamic ATR/BB range.
"""

import os
import sys
import json
import time
import threading
import logging
from pathlib import Path
from datetime import datetime, timezone

PROJECT_ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
from dotenv import load_dotenv
load_dotenv(PROJECT_ROOT / ".env")

from income_streams import http_util
from income_streams.grid_bot.grid_bot import BinanceGridBot

logging.basicConfig(level=logging.INFO, format="%(asctime)s [GRID_MATRIX] %(message)s")
logger = logging.getLogger("grid_matrix")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID", "7746003988")

# Cấu hình 5 cặp — $50 ảo mỗi cặp
PAIRS = [
    {"symbol": "XRPUSDT",  "grids": 10, "usdt": 50.0},
    {"symbol": "SOLUSDT",  "grids": 10, "usdt": 50.0},
    {"symbol": "BNBUSDT",  "grids": 10, "usdt": 50.0},
    {"symbol": "DOGEUSDT", "grids": 10, "usdt": 50.0},
    {"symbol": "ADAUSDT",  "grids": 10, "usdt": 50.0},
]

PNL_PATH = Path(__file__).parent / "pnl_history.jsonl"

def _get_24h_range(symbol: str):
    """Lấy khoảng giá 24h từ Binance để tự động đặt dải lưới."""
    try:
        r = http_util.get(f"https://api.binance.com/api/v3/ticker/24hr?symbol={symbol}", timeout=10)
        d = r.json()
        lo = float(d["lowPrice"])
        hi = float(d["highPrice"])
        cur = float(d["lastPrice"])
        half = (hi - lo) * 0.80 / 2
        return max(0.001, cur - half), cur + half, cur
    except Exception as e:
        logger.warning(f"Failed to get 24h range for {symbol}: {e}")
        return None, None, None

def run_pair(cfg: dict) -> dict:
    """Chạy một cặp, trả về dict tóm tắt PnL."""
    sym = cfg["symbol"]
    lo, hi, cur = _get_24h_range(sym)
    if lo is None:
        return {"symbol": sym, "status": "ERROR", "reason": "price fetch failed"}

    bot = BinanceGridBot(
        symbol=sym,
        price_low=lo,
        price_high=hi,
        grid_count=cfg["grids"],
        total_usdt=cfg["usdt"],
        dry_run=True,
    )
    orders = bot.setup_grid()

    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "symbol": sym,
        "current_price": cur,
        "grid_low": round(lo, 6),
        "grid_high": round(hi, 6),
        "grids": cfg["grids"],
        "usdt_allocated": cfg["usdt"],
        "orders_placed": len(orders),
        "mode": "PAPER",
        "status": "OK",
    }
    with open(PNL_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    logger.info(f"[{sym}] Grid set: {lo:.4f}–{hi:.4f} | {len(orders)} orders | cur={cur:.4f}")
    return record

def send_summary(results: list):
    if not TELEGRAM_BOT_TOKEN:
        return
    lines = "\n".join(
        f"• <b>{r['symbol']}</b>: <code>{r['grid_low']:.4f}–{r['grid_high']:.4f}</code> "
        f"({r['orders_placed']} orders)" if r["status"] == "OK"
        else f"• <b>{r['symbol']}</b>: ❌ {r.get('reason', '')}"
        for r in results
    )
    text = (
        f"🤖 <b>MULTI-PAIR GRID MATRIX</b> 🤖\n\n"
        f"{lines}\n\n"
        f"💰 <b>Tổng vốn ảo:</b> <code>$250 USDT (Paper Trading)</code>\n"
        f"⏰ <code>{datetime.now(timezone.utc).strftime('%H:%M UTC')}</code>"
    )
    try:
        http_util.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": text, "parse_mode": "HTML",
                  "disable_web_page_preview": True},
            timeout=12
        )
    except Exception as e:
        logger.error(f"Telegram error: {e}")

def run():
    """Entry point cho multi_stream_runner.py."""
    logger.info("Starting Multi-Pair Grid Matrix (5 pairs)...")
    results = []
    threads = []

    def _run(cfg):
        results.append(run_pair(cfg))

    for cfg in PAIRS:
        t = threading.Thread(target=_run, args=(cfg,), daemon=True)
        threads.append(t)
        t.start()
        time.sleep(0.5)

    for t in threads:
        t.join(timeout=60)

    send_summary(results)
    return results

if __name__ == "__main__":
    run()
