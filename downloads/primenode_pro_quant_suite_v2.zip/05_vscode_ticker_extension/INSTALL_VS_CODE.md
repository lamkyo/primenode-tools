# Crypto Status Bar Ticker

> **Live BTC, ETH, SOL & EVM Gas prices directly in your VS Code Status Bar.**  
> Zero context switching. Always-on market awareness.

---

## ✨ Features

| Feature | Free | Pro (GitHub Sponsors) |
|---------|------|-----------------------|
| BTC / ETH / SOL prices | ✅ | ✅ |
| EVM Gas (Gwei) | ✅ | ✅ |
| Custom refresh interval | ✅ | ✅ |
| More than 3 coins | ❌ | ✅ |
| Price alerts | ❌ | ✅ |
| Custom API endpoint | ❌ | ✅ |

---

## 🚀 Installation

### From source (local)
```bash
# Clone the repo
git clone <your-repo>
cd vscode_ticker

# Install vsce (if not installed)
npm install -g @vscode/vsce

# Package the extension
vsce package

# Install in VS Code
code --install-extension crypto-status-bar-ticker-1.0.0.vsix
```

### From VS Code Marketplace
> Coming soon — search "Crypto Status Bar Ticker"

---

## ⚙️ Configuration

Open **Settings** → search `cryptoTicker`:

```json
{
  "cryptoTicker.coins": ["BTC", "ETH", "SOL"],
  "cryptoTicker.showGas": true,
  "cryptoTicker.refreshInterval": 30,
  "cryptoTicker.proKey": ""
}
```

---

## 💰 Unlock Pro

Support development on **GitHub Sponsors** and get a Pro license key:

👉 **[https://github.com/sponsors/lam534410](https://github.com/sponsors/lam534410)**

Or run the command: `Crypto Ticker: Unlock Pro (GitHub Sponsors)`

---

## 🔒 Privacy

- **Zero telemetry.** No data sent anywhere except the Binance public API for prices.
- Prices fetched from `api.binance.com` (public endpoint, no auth required).
- Gas from `api.etherscan.io` (public endpoint).
