"""Funding Rate Arbitrage Scanner — Delta-Neutral.
Long Spot + Short Perps khi funding > ngưỡng → ăn funding 3 lần/ngày, hedge giá.
Chỉ quét + báo Telegram, KHÔNG tự mở lệnh (an toàn).
"""
import json, logging
from datetime import datetime, timezone
from pathlib import Path
import os, sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent.parent / ".env")
from income_streams import http_util

logging.basicConfig(level=logging.INFO, format="%(asctime)s [FUNDING] %(message)s")
logger = logging.getLogger("funding")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
REF_CODE = os.getenv("BINANCE_REFERRAL_CODE", "CPA_00V449LLU4")
THRESHOLD = 0.0003  # 0.03% / 8h ≈ 32% APR
EXEC_THRESHOLD = 0.0005  # 0.05%/8h ≈ 54% APR → xét EXECUTE ARB
LOG_PATH = Path(__file__).parent / "funding_opportunities.jsonl"
METRICS_PATH = Path(__file__).parent / "hedged_arb_metrics.jsonl"
STATE_PATH = Path(__file__).parent / "arb_state.json"
FAPI = "https://fapi.binance.com"

# Chi phí thực tế (Binance VIP0): spot taker 0.1% x2 đầu vào/ra, futures taker 0.05% x2
SPOT_FEE_RT = 0.001      # 0.1% mỗi chiều
FUT_FEE_RT = 0.0005      # 0.05% mỗi chiều
SLIPPAGE_RT = 0.0005     # 0.05% mỗi chiều
ROUNDTRIP_COST_RT = 2 * (SPOT_FEE_RT + SLIPPAGE_RT) + 2 * (FUT_FEE_RT + SLIPPAGE_RT)  # ≈ 0.5%

import html as _html

def send_telegram(msg: str):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return
    try:
        http_util.post(f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": msg}, timeout=10)
    except Exception:
        pass

def _load_state() -> dict:
    try:
        return json.loads(STATE_PATH.read_text())
    except Exception:
        return {"open": {}, "last_rates": {}}

def _save_state(s: dict) -> None:
    STATE_PATH.write_text(json.dumps(s, indent=2))

def net_yield_24h(rate_8h: float) -> dict:
    """Lãi funding 3 kỳ/24h trừ roundtrip cost. Dương → EXECUTE."""
    gross = rate_8h * 3
    net = gross - ROUNDTRIP_COST_RT
    return {"gross_24h_pct": round(gross * 100, 4), "cost_pct": round(ROUNDTRIP_COST_RT * 100, 4),
            "net_24h_pct": round(net * 100, 4), "executable": net > 0}

BYBIT_TICKERS = "https://api.bybit.com/v5/market/tickers?category=linear"

def fetch_bybit_funding() -> dict:
    """Quet Bybit linear tickers -> funding rate (best-effort, fail-soft)."""
    try:
        r = http_util.get(BYBIT_TICKERS, timeout=20)
        out = {}
        for t in r.json().get("result", {}).get("list", []):
            try:
                out[t["symbol"]] = float(t.get("fundingRate", 0) or 0)
            except (TypeError, ValueError):
                continue
        return out
    except Exception as e:
        logger.warning(f"Bybit fetch fail (soft): {e}")
        return {}

def scan_cross_exchange(symbols: list | None = None) -> list:
    """So sanh funding Binance vs Bybit cho cac symbol chung. Fail-soft."""
    try:
        bstate = _load_state()
        bybit = fetch_bybit_funding()
        rows = []
        for sym, brate in (symbols or sorted(bstate.get("last_rates", {}))) and [] or []:
            pass
        for sym in (symbols or [s for s in bstate.get("last_rates", {})]):
            if sym in bybit:
                rows.append({"symbol": sym, "binance": bstate["last_rates"][sym],
                             "bybit": bybit[sym],
                             "spread": round(bstate["last_rates"][sym] - bybit[sym], 6)})
        rows.sort(key=lambda x: abs(x["spread"]), reverse=True)
        return rows[:10]
    except Exception as e:
        logger.warning(f"cross-exchange fail (soft): {e}")
        return []

def scan(min_rate: float = THRESHOLD, top_n: int = 5) -> dict:
    r = http_util.get(f"{FAPI}/fapi/v1/premiumIndex", timeout=30)
    data = r.json()
    state = _load_state()
    opps, executables, exits = [], [], []
    for d in data:
        try:
            rate = float(d.get("lastFundingRate", 0))
        except (TypeError, ValueError):
            continue
        sym = d.get("symbol", "")
        if not sym.endswith("USDT"):
            continue
        prev = state["last_rates"].get(sym)
        # Early-exit: funding đảo dương→âm khi đang "mở" vị thế mô phỏng
        if sym in state["open"] and prev is not None and prev > 0 and rate <= 0:
            exits.append(sym)
            del state["open"][sym]
            send_telegram(f"CANH BAO DONG LENH {sym}: funding dao {prev*100:.4f}% ve {rate*100:.4f}%/8h. "
                          f"Thoat vi the mo phong de bao ve von.")
        state["last_rates"][sym] = rate
        if rate < min_rate:
            continue
        apr = rate * 3 * 365 * 100
        item = {"symbol": sym, "mark_price": d.get("markPrice"),
                "funding_rate_8h_pct": round(rate * 100, 4),
                "est_apr_pct": round(apr, 1), "next_funding": d.get("nextFundingTime")}
        # Delta-neutral mô phỏng khi funding > 0.05%/8h
        if rate >= EXEC_THRESHOLD:
            ny = net_yield_24h(rate)
            item["hedge"] = {"long_spot": "100%", "short_perp": "100%", **ny}
            state["open"].setdefault(sym, {"since": datetime.now(timezone.utc).isoformat(),
                                           "rate": rate})
            with open(METRICS_PATH, "a") as f:
                f.write(json.dumps({"ts": datetime.now(timezone.utc).isoformat(), **item}) + "\n")
            if ny["executable"]:
                executables.append(item)
        opps.append(item)
    _save_state(state)
    opps.sort(key=lambda x: x["est_apr_pct"], reverse=True)
    entry = {"ts": datetime.now(timezone.utc).isoformat(), "threshold_pct": min_rate * 100,
             "count": len(opps), "executables": len(executables),
             "early_exits": exits, "top": opps[:top_n]}
    with open(LOG_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")
    try:
        xrows = scan_cross_exchange([o["symbol"] for o in opps[:20]])
        if xrows:
            entry["cross_exchange_top"] = xrows[:5]
    except Exception:
        pass
    logger.info(f"Found {len(opps)} opps, {len(executables)} EXECUTE, {len(exits)} exits")
    if executables:
        best = executables[0]
        send_telegram(f"EXECUTE ARB {best['symbol']}: funding {best['funding_rate_8h_pct']}%/8h, "
                      f"net 24h +{best['hedge']['net_24h_pct']}% sau phi. "
                      f"Mo phong Long Spot + Short Perp size bang nhau. Chi tiet: {best['hedge']}")
    elif opps:
        top = opps[0]
        send_telegram(f"Funding scan: {len(opps)} co hoi, top {top['symbol']} {top['funding_rate_8h_pct']}%/8h "
                      f"(chua du net duong sau phi, khong EXECUTE).")
    return entry

if __name__ == "__main__":
    print(json.dumps(scan(), indent=2))
