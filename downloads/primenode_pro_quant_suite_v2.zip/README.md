# PrimeNode Pro Quantitative Suite — Quickstart Guide

Welcome to the **PrimeNode Pro Quantitative Trading Suite**.
This package contains institutional-grade automated trading algorithms, delta-neutral yield scanners, and technical analysis indicators.

---

## 📦 What's Inside

1. **`01_binance_grid_matrix/`**
   - Dynamic 5-pair Grid Trading Bot (`XRPUSDT`, `SOLUSDT`, `BNBUSDT`, `DOGEUSDT`, `ADAUSDT`).
   - Automatically adapts grid bounds based on 24h volatility and ATR bands.
   - Default: `DRY_RUN = True` (Paper Trading mode — zero financial risk).

2. **`02_funding_rate_arbitrage/`**
   - Delta-Neutral Funding Rate Arbitrage Scanner across Binance Futures & Bybit Linear.
   - Calculates Net 24h Yield after taker fees and slippage.
   - Detects spreads exceeding 50% to 150% annualized APR.

3. **`03_volume_breakout_scalper/`**
   - 5-Minute Volume Spike Breakout Scalper scanning 100 USDT pairs.
   - Dynamic take-profit (+1.5%) and trailing stop-loss (-0.8%).
   - Auto-filters stablecoins and illiquid pairs.

4. **`04_amibroker_mt5_indicators/`**
   - Professional AFL & MQ5 formulas for chartists: Volume Breakout Pro, SuperTrend MTF, Smart Money Concepts (SMC) Liquidity Sweeps, and VN30 Screener.

5. **`05_vscode_ticker_extension/`**
   - Pre-packaged `.vsix` extension for VS Code: Live crypto status bar ticker showing BTC, ETH, SOL, and EVM gas.

---

## ⚡ Quickstart in 3 Steps

### Step 1: Environment Setup
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Step 2: Configure Environment (.env)
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Fill in your Telegram credentials (optional, for real-time alerts):
```ini
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id
# Binance API (Optional: bot runs in PAPER TRADING mode by default without keys!)
BINANCE_API_KEY=
BINANCE_API_SECRET=
```

### Step 3: Run the Engines
```bash
# 1. Run Dynamic Grid Matrix (Paper Mode)
python 01_binance_grid_matrix/multi_pair_runner.py

# 2. Run Funding Arbitrage Scanner
python 02_funding_rate_arbitrage/funding_arb_bot.py

# 3. Run Breakout Volume Scalper
python 03_volume_breakout_scalper/volume_scalper.py
```

---

## 🛡️ Risk Management & Security Rails
- **Safety First**: All bots are configured in **Paper Trading Mode** by default.
- **API Key Security**: When adding API keys, NEVER enable "Withdrawal" permissions. Only enable "Reading" and "Spot/Futures Trading".
- **Delta-Neutrality**: The funding arbitrage bot strictly pairs equal long and short notional values to hedge directional price risk.

---
*© 2026 PrimeNode Trading Technologies. All rights reserved.*
