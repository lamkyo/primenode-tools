"""Shared HTTP utilities with trust_env=False to avoid proxy conflicts."""
import httpx

def make_client(**kwargs) -> httpx.Client:
    """Create httpx Client with trust_env=False (needed in this env)."""
    kwargs.setdefault("trust_env", False)
    kwargs.setdefault("timeout", 30)
    return httpx.Client(**kwargs)

import time

def post(url: str, **kwargs) -> httpx.Response:
    """httpx.post wrapper with trust_env=False and auto-retry for 429 rate limits."""
    kwargs.setdefault("timeout", 15)
    with httpx.Client(trust_env=False) as c:
        resp = c.post(url, **kwargs)
        if resp.status_code == 429 and "api.telegram.org" in url:
            try:
                wait_sec = min(int(resp.json().get("parameters", {}).get("retry_after", 1)), 3)
            except Exception:
                wait_sec = 1
            time.sleep(wait_sec)
            try:
                resp = c.post(url, **kwargs)
            except Exception:
                pass
        return resp

def get(url: str, **kwargs) -> httpx.Response:
    """httpx.get wrapper with trust_env=False."""
    kwargs.setdefault("timeout", 30)
    with httpx.Client(trust_env=False) as c:
        return c.get(url, **kwargs)

def send_telegram_alert(token: str, chat_id: str, text: str, parse_mode: str = "HTML") -> bool:
    """Send Telegram message safely with timeout and error suppression."""
    if not token or not chat_id:
        return False
    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        resp = post(url, json={"chat_id": chat_id, "text": text, "parse_mode": parse_mode, "disable_web_page_preview": True}, timeout=12)
        return resp.status_code == 200
    except Exception:
        return False
